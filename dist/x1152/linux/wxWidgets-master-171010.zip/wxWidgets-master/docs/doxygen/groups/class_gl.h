/////////////////////////////////////////////////////////////////////////////
// Name:        class_gl.h
// Purpose:     OpenGL classes group docs
// Author:      wxWidgets team
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_gl OpenGL
@ingroup group_class

Classes interfacing wxWidgets with OpenGL (http://opengl.org/).

*/

