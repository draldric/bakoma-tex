/////////////////////////////////////////////////////////////////////////////
// Name:        class_pickers.h
// Purpose:     Picker Control classes group docs
// Author:      wxWidgets team
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_pickers Picker Controls
@ingroup group_class

A picker control is a control whose appearance and behaviour is highly
platform-dependent.

*/

